<div class="col-md-2">
    <ul class="sidebar navbar-nav toggled">
        <li class="nav-item <?php echo e(Route::current()->uri == 'admin/dashboard' ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('admin.dashboard')); ?>">
                <i class="fas fa-fw fa-tachometer-alt"></i>
                <span>Dashboard</span>
            </a>
        </li>

        
        
        
        
        
            
                
                
            
            

                
                
                
                
                    
                    
                    
                    
                
            
        
        
            
                
                
        
        
            
                
                    
                    
            
            
                
                    
                    
            
        
        
            
        
        
        
        
                
                    
                    
                
                
                    
                    
                    
                    
                    
                    
                    
                
            


        
        
        
        
        
        
        
            
                
                
            
            
                
                
                
                
            
        
    </ul>
</div>