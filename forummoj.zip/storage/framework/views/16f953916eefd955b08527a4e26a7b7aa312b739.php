<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-md-10 mt-5">
        <div class="card">
            <div class="card-header">
                <h3><?php echo e($user->name); ?></h3>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4">
                        <img src="<?php echo e($user->getAvatar()); ?>" width="200px">
                        <p class="mt-3">Member since <?php echo e($user->profile->showDate()); ?></p>
                    </div>
                    <div class="col-md-8">
                        <h5>About me:</h5>
                        <?php echo $user->profile->about ?? '<p class="font-weight-light font-italic">Empty</p>'; ?>

                        <h6>Country/City</h6>
                        <p><?php echo $user->profile->country ?? '<p class="font-weight-light font-italic">Empty</p>'; ?>/<?php echo $user->profile->country ?? '<p class="font-weight-light font-italic">Empty</p>'; ?></p>
                        <h6>Contact Email</h6>
                        <p><?php echo $user->profile->email ?? '<p class="font-weight-light font-italic">Empty</p>'; ?></p>
                        <h6>Web</h6>
                        <p><?php echo $user->profile->web ?? '<p class="font-weight-light font-italic">Empty</p>'; ?></p>
                        <h6>Working as</h6>
                        <p><?php echo $user->profile->job ?? '<p class="font-weight-light font-italic">Empty</p>'; ?></p>
                    </div>
                </div>
                <div class="row">
                    <div class="card m-2 w-100">
                        <ul class="nav nav-tabs m-2" id="myTab" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">Questions</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Replies</a>
                            </li>

                        </ul>
                        <div class="tab-content m-2" id="myTabContent">
                            <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                                <?php if($user->questions): ?>
                                    <?php $__currentLoopData = $user->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <p><a href="<?php echo e(route('question.show',['slug'=>$question->slug])); ?>"><?php echo e($question->title); ?></a></p>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                    <p>You don't have any questions</p>
                                <?php endif; ?>
                            </div>
                            <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                                <?php if($user->replies): ?>
                                    <?php $__currentLoopData = $user->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <p><a href="<?php echo e(route('question.show',['slug'=>$reply->question->slug])); ?>"><?php echo $reply->shortenText($reply->content, 10); ?></a></p>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <p>You don't have any questions</p>
                                <?php endif; ?>
                            </div>

                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>