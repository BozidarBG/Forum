<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4>Complaints</h4>
                </div>
                <div class="card-body">
                    <table class="table table-responsive-sm">
                        <thead>
                        <tr>
                            <th>Reported</th>
                            <th>Reported by</th>
                            <th>Message</th>
                            <th>Link</th>
                        </tr>
                        </thead>

                        <tbody >
                        <?php $__currentLoopData = $complaints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $complaint): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-danger"><?php echo e($complaint->getReportedUser()); ?></td>
                                <td class="text-info"><?php echo e($complaint->getUserWhoComplained()); ?></td>
                                <td class="text-justify w-50"><?php echo $complaint->body; ?></td>
                                <td><a href="<?php echo e($complaint->link); ?>"
                                       class="btn btn-secondary btn-sm" data-toggle="tooltip"
                                       data-placement="left" title="<?php echo e($complaint->link); ?>" target="_blank">Link
                                    </a>
                                </td>
                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <div class="text-center">
                        <?php echo $complaints->links(); ?>

                    </div>

                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>