<?php $__env->startSection('content'); ?>
    <div class="col-md-2  left-column">
        <h4 class="text-center">Tags</h4>
        <div class="list-group">
            <?php if($tags): ?>
            <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a class="list-group-item" href="<?php echo e(route('tags', ['slug'=>$tag->slug])); ?>"><?php echo e($tag->title); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>

    </div>
    <div class="col-md-7 middle-column">
        <?php echo $__env->make('success-error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <h4 class="text-center">Questions</h4>
        <nav class="navbar navbar-expand-lg navbar-light bg-light mb-2">
            <div class="navbar-nav">
                <a class="nav-item nav-link active" href="<?php echo e(route('start')); ?>">Newest</a>
                <a class="nav-item nav-link" href="#">Most answered</a>
                <a class="nav-item nav-link" href="#">Most voted</a>
            </div>
        </nav>
        <!-- card/question start -->
        <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card mb-4">
            <div class="card-header">
                <div class="media">
                    <img class="mr-3" src="<?php echo e($question->user->getAvatar()); ?>" alt="user-image">
                    <div class="media-body">
                        <a href="#" class="question-text mt-0 mb-1">
                            <?php echo e($question->user->name); ?> has asked:
                        </a>
                        <br>
                        <a href="<?php echo e(route('question.show',['slug'=>$question->slug])); ?>" class="question-text mt-1 mb-1">
                            <?php echo e($question->title); ?>

                        </a>
                    </div>
                </div>
            </div>

            <div class="card-body text-center">
                <button type="button" class="btn btn-outline-primary mr-3" disabled>
                    Views <span class="badge badge-primary"><?php echo e($question->views / 2); ?></span>
                </button>
                <button type="button" class="btn btn-outline-success mr-3" disabled>
                    Answers <span class="badge badge-success"><?php echo e($question->replies->count()); ?></span>
                </button>
                <button type="button" class="btn btn-outline-warning" disabled>
                    Votes <span class="badge badge-warning">5</span>
                </button>
            </div>
            <div class="card-footer text-center">
                <small class="text-muted"><?php echo e($question->created_at->diffForHumans()); ?></small>
                <?php $__currentLoopData = $question->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="btn btn-info btn-sm" href="<?php echo e(route('tags', ['slug'=>$tag->slug])); ?>"><?php echo e($tag->title); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo $questions->links(); ?>

        <!-- card/question end -->

    </div>
    <div class="col-md-3 right-column">
        <div class="card">
            <h5 class="card-title text-center mt-3">Ask a question</h5>
            <img class="question-image" src="<?php echo e(asset('images/question.png')); ?>" alt="Question">
            <div class="card-body">
                <h5 class="card-title">But before you ask:</h5>
            </div>
            <ul class="list-group list-group-flush">
                <li class="list-group-item">- please see if this question was asked before</li>
                <li class="list-group-item">- please note that we don't tolerate foul language</li>
            </ul>
            <div class="card-body">
                <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(route('question.create')); ?>" class="btn btn-block btn-primary">Ask a question</a>
                <?php else: ?>
                    <a class="btn btn-block btn-primary start-login-modal" href="#">Login</a>
                <div class="text-center">or</div>
                    <a class="btn btn-block btn-primary start-register-modal"  href="#">Register</a>
                <div class="text-center">to ask a question</div>
                <?php endif; ?>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>