<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-md-10 mt-5">
        All Users
        <div class="row">
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <div class="card my-1">
                        <div class="card-body">
                            <a href="<?php echo e(route('show.user', ['hashid'=>$user->hashid])); ?>"><img src="<?php echo e(asset($user->getAvatar())); ?>" width="100px"></a>
                            <p>
                                <?php if(Auth::check() && Auth::id()== $user->id): ?>
                                    <a href="<?php echo e(route('my.profile')); ?>"><?php echo e($user->name); ?></a>
                                    <?php else: ?>
                                    <a href="<?php echo e(route('show.user', ['hashid'=>$user->hashid])); ?>"><?php echo e($user->name); ?></a>
                                <?php endif; ?>
                            </p>
                            <p><?php echo $user->profile->shortenText($user->profile->about, 10); ?></p>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <ul class="pagination mt-3">
            <?php echo e($users->links()); ?>

        </ul>
    </div>

<?php $__env->stopSection(); ?>>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>