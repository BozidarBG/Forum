<div class="row">
    <?php if(Session::has('success')): ?>
    <div class="alert alert-success">
        <p><?php echo e(Session::get('success')); ?></p>
    </div>
    <?php endif; ?>
    <?php if(Session::has('error')): ?>
    <div class="text-center alert alert-danger">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p><?php echo e($error); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>
</div>