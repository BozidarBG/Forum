<?php $__env->startSection('content'); ?>
<div class="card p-1">

    
    <div class="row">

        <div class="col-md-8">
            <div class="card">
                <?php echo csrf_field(); ?>

                <div class="card-header">
                    <h3>All Subjects</h3>
                </div>
                <div class="card-body">
                    <table class="table table-responsive">
                        <thead>
                            <tr>
                                <th class="subject_title">Title</th>
                                <th class="subject_questions">Questions</th>
                                <th class="subject_btn">Edit</th>
                                <th class="subject_btn">Delete</th>
                            </tr>
                        </thead>

                        <tbody>
                        <?php if($subjects->count()>0): ?>
                        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr data-id="<?php echo e($subject->id); ?>">
                                <td class="subject_title"><?php echo e($subject->title); ?></td>
                                <td class="subject_question">85</td>
                                <td class="subject_btn"><button class="btn btn-sm btn-info edit">Edit</button></td>
                                <td class="subject_btn"><button class="btn btn-sm btn-danger delete">Delete</button></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <tr><td>There are no subjects</td></tr>
                        </tbody>
                        <?php endif; ?>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    <h3>Create Subject</h3>
                </div>
                <div class="card-body">
                    <form id="create" method="post">

                        <div class="form-group">
                            <input type="text" id="title" class="form-control" placeholder="Enter title" required>
                        </div>
                        <div class="form-group">
                            <button class="btn btn-block btn-primary" type="submit">Create Subject</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    let token=$('[name="_token"]').val();

    let editObj={};
    addEditAndDeleteListeners();

    //gives edit and delete listeners to all buttons with .edit and .delete
    function addEditAndDeleteListeners(){
        $('.edit').on('click', function(event){
            editSubject(event);
        });

        $('.delete').on('click', function(event){
            deleteSubject(event);
        });
    }

    //CREATE NEW SUBJECT
    $('#create').on('submit', function(){
        event.preventDefault();
        let title=$('#title').val();
        if(title.length>=1){
            let form_data="title="+title+"&_token="+token;

            $.ajax({
                url:"/subjects",
                method:'post',
                data:form_data,
                dataType:'json',
                success: function(data){
                    if(data.success){
                        let row=`<tr data-id="${data.id}">
                                <td class="subject_title">${data.title}</td>
                                <td class="subject_question">0</td>
                                <td class="subject_btn"><button class="btn btn-sm btn-info edit">Edit</button></td>
                                <td class="subject_btn"><button class="btn btn-sm btn-danger delete">Delete</button></td>
                                </tr>`;
                        $('tbody').append(row);
                        $('#title').val('');
                        addEditAndDeleteListeners();
                    };
                }

            });
        }
    });
    //END CREATE NEW SUBJECT


    //EDIT SUBJECT

    function editSubject(event) {
        event.preventDefault();
        //removes click listener for edit button
        $(event.target).off('click');
        let tableRow = $(event.target).closest('tr');
        let id = tableRow.attr('data-id');
        let oldTitle = tableRow.children('.subject_title').text();

        //when we click edit, we take id and title and put it in editObj. id is prop name and odlTitle is value
        if(!editObj.hasOwnProperty(id)){
            editObj[id]=oldTitle;
        }

        //change edit btn to cancel btn and delete btn to save btn
        $(event.target).removeClass('btn-info edit').addClass('btn-warning cancel').text('Cancel');
        let deleteBtn = $(event.target).parent().next().children('.delete');
        deleteBtn.removeClass('btn-danger delete').addClass('btn-success save').text('Save');

        //add input field with old value and put it in td where old value was
        let inputField = "<input type='text' value='" + editObj[id] + "'>";
        $(event.target).parent().prev().prev().html(inputField);

        //if we click cancel, we have to take id of clicked cancel btn and find in edits title of that id and
        //return to edit and delete
        $('.cancel').on('click', function (event) {
            removeCancel(event)
        });
        $('.save').on('click', function(event){
            saveDataByAjax(event);
        })
    }

    function removeCancel(event) {
        let cancelId = $(event.target).closest('tr').attr('data-id');
        let oldTitle = editObj[cancelId];

        //return to old td, edit & delete
        $(event.target).off('click');
        $(event.target).removeClass('btn-warning cancel').addClass('btn-info edit').text('Edit');
        $(event.target).parent().next().children().removeClass('btn-success save').addClass('btn-danger delete').text('Delete');
        $(event.target).parent().prev().prev().html(oldTitle);
        //give everyone edit and delete listeners
        addEditAndDeleteListeners();
    }

        //if we click save, we are sending ajax request
        function saveDataByAjax(event){
            event.preventDefault();
            //check if new value is different from old value
            let saveId = $(event.target).closest('tr').attr('data-id');
            let oldTitle = editObj[saveId];
            let newTitle=$(event.target).closest('tr').children().children().val();
            //console.log(saveId, oldTitle, newTitle);
            if(oldTitle != newTitle){
                //titles are different and we send ajax
                let form_data="id="+saveId+"&title="+newTitle+"&_token="+token;

                $.ajax({
                    url:"/subjects-update",
                    method:'post',
                    data:form_data,
                    dataType:'json',
                    success: function(data){
                        if(data.success){
                            //update value in the row and bring back cancel and save
                            $(event.target).parent().prev().prev().prev().html(newTitle);

                            $(event.target).removeClass('btn-success save').addClass('btn-danger delete').text('Delete');
                            $(event.target).parent().prev().children().removeClass('btn-warning cancel').addClass('btn-info edit').text('Edit');
                            //remove it from edit object
                            if(editObj.hasOwnProperty(saveId)){
                                delete editObj[saveId];
                            }
                            //give everyone edit and delete listeners
                            addEditAndDeleteListeners();
                        }
                    }

                });
            }
        }

    //END EDIT SUBJECT

    //DELETE SUBJECT
function deleteSubject(event){
    event.preventDefault();
    let rowToDelete = $(event.target).closest('tr');
    let id=rowToDelete.attr('data-id');
    if(id){
        let form_data="id="+id+"&_token="+token;
        $.ajax({
            url:"/subjects-destroy",
            method:'post',
            data:form_data,
            dataType:'json',
            success: function(data){
                if(data.success){
                    //remove row
                    rowToDelete.css('background', 'red');
                    rowToDelete.fadeOut(2000);
                }
            }

        });
    }
}
    //END DELETE SUBJECT
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>